#include "Converter.h"
CAN_Frame Converter::convertToFrame(const CAN_Message &message)
{
    CAN_Frame frame{};
    frame.id = message.identifier;
    frame.dlc = message.length;
    for (int i = 0; i < 8; i++)
    {
        frame.data[i] = message.payload[i];
    }
    return frame;
}
CAN_Message Converter::convertToMessage(const CAN_Frame &frame)
{
    CAN_Message returnMessage;
    returnMessage.identifier = frame.id;
    returnMessage.length = frame.dlc;
    for (int i = 0; i < frame.dlc; i++)
    {
        returnMessage.payload[i] = frame.data[i];
    }
    return returnMessage;
}