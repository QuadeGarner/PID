#ifndef TRANSPORT
#define TRANSPORT
#include <cstdint>
struct CAN_Message
{
    // J1939Identifier
    uint32_t identifier;
    uint16_t length;
    uint8_t payload[1785];
};
#endif