#include "CommunicationManager.h"
void CommunicationManager::send(const CAN_Message &message)
{
    if (message.length <= 8)
    {

        node.send(Converter::convertToFrame(message));
    }
    else
    {
        tp.startTransfer(message);
    }
}

void CommunicationManager::receiveFrame(const CAN_Frame &frame)
{
    tp.receiveMessage(Converter::convertToMessage(frame));
    if (tp.messageReady())
    {
        application.receiveMessage(tp.getMessage());
    }
}
CommunicationManager::CommunicationManager(DeviceID id, CanBusManager &bus, IMessageReceiver &receiver) : node(id, bus, *this), application(receiver) {}

void CommunicationManager::process()
{
    CAN_Message message = tp.process();
    if (message.length == 0 && message.identifier == 0)
    {
        return;
    }
    node.send(Converter::convertToFrame(message));
}
