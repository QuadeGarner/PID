#ifndef MOTOR_COMMANDS
#define MOTOR_COMMANDS
#include <cstdint>
enum class MotorCommand
{
    MOVE,
    HOME,
    STOP,
    ENABLE,
    DISABLE
};
enum class DeviceID : uint8_t
{
    // Default
    NONE,
    // Broadcast
    ALL_DEVICES,
    // Motors
    FRONT_LEFT_MOTOR_CONTROLLER,
    FRONT_RIGHT_MOTOR_CONTROLLER,
    BACK_LEFT_MOTOR_CONTROLLER,
    BACK_RIGHT_MOTOR_CONTROLLER,
    // Encoders
    FRONT_LEFT_ENCODER,
    FRONT_RIGHT_ENCODER,
    BACK_LEFT_ENCODER,
    BACK_RIGHT_ENCODER,
    // Sensors
    IMU,
    // System
    TELEMETRY_MANAGER,
    DIAGNOSTICS_MANAGER,
    MOTION_COORDINATOR,
    PID_CONTROLLER,
    MOTOR_CONTROLLER

};
#endif